/*
 * This is the Main class that starts the program.  It creates a Programloop
 * object and then starts the program.
 */
public class Main {
	public static void main(String theArgs[]) 
	{
		new ProgramLoop().startProgram();
	}
}
