import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class ProgramLoopTest {

	@Before
	public void setUp() throws Exception {
	}

//	@Test
//	public void testProgramLoop() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	@Test
//	public void testStartProgram() {
//		fail("Not yet implemented"); // TODO
//	}

	@Test
	public void testLoadUsers() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testLoadAuctions() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckLogin() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testCheckAuctions() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testOutputUsers() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testOutputAuctions() {
		fail("Not yet implemented"); // TODO
	}

}
